# coding: utf-8
from site import addsitedir


addsitedir("../lib")
